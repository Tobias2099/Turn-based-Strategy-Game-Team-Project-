#ifndef __LINKBOOST_CC__
#define __LINKBOOST_CC__

#include "ability.h"
#include "game.h"

class LinkBoost : public Ability {
  public:
    void execute(Game& game, int x, int y, string linkName) {
      //use appearanceToID and whoAt
      
    }

};

#endif
